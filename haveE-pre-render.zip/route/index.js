import Route from 'vue-router'
import Vue from 'vue'
import routes from './routes'

Vue.use(Route)

export const router = new VueRouter({
  routes,
  model: 'history'
})