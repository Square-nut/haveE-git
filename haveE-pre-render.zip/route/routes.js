export default [{
  path: '/index',
  components: []
}]