var version = 'dev';
var serviceUrlOld = '//console.300.cn';