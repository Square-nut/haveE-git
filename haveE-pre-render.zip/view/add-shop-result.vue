<template>

  <div class="add-shop-result dn">
    <div class="result-success tc dn">
      <div>
        <img class="dib"
             style="width: 180px;margin: auto;"
             src="images/shop-success.png"
             alt="">
      </div>
      <p class="f18 tc"
         style="margin-top: 62px;">店铺创建成功</p>
    </div>
    <div class="result-fail tc dn">
      <div>
        <img style="width: 180px;margin: auto;"
             src="images/iphone_03.png"
             alt="">
      </div>
      <p class="f18 tc"
         style="margin-top: 62px;">抱歉，您已试用过此产品，试用版本不可以重复开通</p>
    </div>
    <div class="tc"
         style="margin-bottom: 48px;margin-top: 17px;">
      <a href="http://new-console.aiyouyi.cn"
         class="primary-color mr30 checked-your-shop-btn">查看您的店铺</a>
      <a href="index.html"
         class="primary-color">返回首页</a>
    </div>
    <div class="service-panel"
         style="margin-bottom: 78px;">
      <div style="margin-bottom: 23px;">如果您有任何问题，可以联系客服：</div>
      <div>
        <img src="images/tel-icon_03.png"
             style="width:20px;height:20px;"
             alt=""
             srcset="">
        <span class="f14 primary-color"
              style="margin-left: 8px;margin-right: 12px;">7 x 24小时客服热线</span>
        <span class=" f20"
              style="color: #cb3718;">400-660-5555</span>
      </div>
    </div>
  </div>
</template>
