<template>
  <div class="add-agent-result dn">
    <div class="resultSuccess"
         style="width: 730px;margin: 120px auto 0;">
      <div class="dib mr30 vt">
        <img src="images/note_03.png"
             alt="">
      </div>
      <div class="dib vt"
           style="width: 500px;margin: auto;">
        <p class="f16 lh20"><b>代理申请已提交</b></p>
        <p class="f12 color999 lh20 mt20">感谢您对有翼的信任，我们会尽快进行筛选，请保持“联系人手机号”的 畅通，以免错过合作机会。</p>
        <div class="service-panel"
             style="margin-bottom: 78px;">
          <div style="margin-bottom: 23px;">如果您有任何问题，可以联系客服：</div>
          <div>
            <img src="images/tel-icon_03.png"
                 style="width:20px;height:20px;"
                 alt=""
                 srcset="">
            <span class="f14 primary-color"
                  style="margin-left: 8px;margin-right: 12px;">7 x 24小时客服热线</span>
            <span class=" f20"
                  style="color: #cb3718;">400-660-5555</span>
          </div>
        </div>
      </div>
    </div>
</template>
