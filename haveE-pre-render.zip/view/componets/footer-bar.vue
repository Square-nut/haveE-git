<template>

  <div class="footer">
    <p>版权所有 © 1999-2019 中企动力科技股份有限公司 Copyright © 1999-2019 300.cn All Rights Reserved </p>
    <p>京公网安备11030102010293号京ICP证010249-2</p>
  </div>
</template>

<script>
export default {
  data () {
    return {

    }
  }
}
</script>
