<template>
  <div class="links">
    <div class="wrapper">
      <ul>
        <li class="links-lingshou">
          <a href="">
            <strong>新零售</strong>
            <p>线上零售行业品牌电商、门店零售行业解决方案</p>
          </a>
        </li>
        <li class="links-fuwu">
          <a href="">
            <strong>新服务</strong>
            <p>线服务于广大实体行业，提供客户沉淀、提升复购、低成本拓客的线下门店解决方案</p>
          </a>
        </li>
        <li>
          <div class="tel">
            <strong>联系我们</strong>
            <p>开店咨询：010-12345678</p>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {

    }
  }
}
</script>
