<template>
  <div class="header">
    <div class="header-con">
      <a href=""
         class="logo"></a>
      <div class="logo_rt">
        <a href="">
          <h1>有翼云</h1>
          <p>助力企业打造自有生态链</p>
        </a>
      </div>
      <ul class="nav">
        <li class="active"><a href=""
             class="product-center">首页</a></li>
        <li class="product-dropdown"><a href="javascript:;"
             class="product-center">商家服务<i class="caret"></i></a>
          <div class="dropdown-menu-wrapper">
            <div class="dropdown-menu">
              <div class="item-container">
                <div class="item-product"><a href=""
                     class="item-product-link"><span class="icon-xls"></span>
                    <h3>新零售</h3>
                    <p>商城丨分销丨营销丨会员丨多商户管理</p>
                  </a></div>
                <div class="item-product"><a href=""
                     class="item-product-link"><span class="icon-xfw"></span>
                    <h3>新服务</h3>
                    <p>店铺丨会员丨营销丨外卖丨预约丨支付</p>
                  </a></div>
              </div>
            </div>
          </div>
        </li>
        <li><a href=""
             class="product-center">渠道合作</a></li>
        <li><a href=""
             class="product-center">关于有翼</a></li>
        <li class="last login_common"><a target="_blank"
             class="btn-login"
             href="">登录</a>
        </li>
        <li class=" last register_common"><a target="_blank"
             href="/register.html">注册</a></li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {

    }
  }
}
</script>
